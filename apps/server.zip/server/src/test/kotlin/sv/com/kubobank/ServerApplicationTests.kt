package sv.com.kubobank

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
